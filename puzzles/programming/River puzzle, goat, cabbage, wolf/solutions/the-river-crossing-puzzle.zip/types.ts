export type Item = 'wolf' | 'goat' | 'cabbage';
export type Location = 'start' | 'end';

export interface GameState {
  locations: Record<Item, Location>;
  boatLocation: Location;
  passenger: Item | null;
  status: 'playing' | 'won' | 'lost';
  message: string;
  moves: number;
  selectedItemOnBank: Item | null;
}
