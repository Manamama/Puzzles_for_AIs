
import React, { useState, useEffect, useCallback } from 'react';
import { Item, Location, GameState } from './types';

const EMOJIS: Record<Item, string> = {
  wolf: '🐺',
  goat: '🐐',
  cabbage: '🥬',
};

const BOAT = '🚣';

const getInitialState = (): GameState => ({
  locations: {
    wolf: 'start',
    goat: 'start',
    cabbage: 'start',
  },
  boatLocation: 'start',
  passenger: null,
  status: 'playing',
  message: 'Click or drag an item to the boat to get started.',
  moves: 0,
  selectedItemOnBank: null,
});

const App: React.FC = () => {
  const [state, setState] = useState<GameState>(getInitialState());

  const checkGameStatus = useCallback(() => {
    // Check for win condition
    const isWon = Object.values(state.locations).every(loc => loc === 'end');
    if (isWon) {
      setState(prev => ({ 
        ...prev, 
        status: 'won', 
        message: `Congratulations! You solved it in ${prev.moves} moves.` 
      }));
      return;
    }

    // Check for loss condition
    const bankWithoutHuman = state.boatLocation === 'start' ? 'end' : 'start';
    const unattendedItems = (Object.keys(state.locations) as Item[]).filter(
      item => state.locations[item] === bankWithoutHuman
    );

    const has = (item: Item) => unattendedItems.includes(item);
    let isLost = false;
    let loseMessage = '';
    
    // User's specific rules: goat/cabbage and wolf/cabbage conflict.
    if (has('goat') && has('cabbage')) {
      isLost = true;
      loseMessage = 'Oh no! The goat ate the cabbage. Game over.';
    } else if (has('wolf') && has('cabbage')) {
      isLost = true;
      loseMessage = 'Oh no! The wolf ruined the cabbage. Game over.';
    }

    if (isLost) {
      setState(prev => ({ ...prev, status: 'lost', message: loseMessage }));
    }
  }, [state.locations, state.boatLocation, state.moves]);
  
  useEffect(() => {
    if (state.status === 'playing' && state.moves > 0) {
      checkGameStatus();
    }
  }, [state.boatLocation, state.status, state.moves, checkGameStatus]);

  const handleItemClick = useCallback((item: Item) => {
    if (state.status !== 'playing') return;

    setState(prev => {
      const { locations, boatLocation } = prev;
      if (locations[item] === boatLocation) {
         return { ...prev, passenger: item, selectedItemOnBank: null }
      }
      return prev;
    });
  }, [state.status]);

  const handleRow = useCallback(() => {
    if (state.status !== 'playing') return;

    setState(prev => {
      const newBoatLocation = prev.boatLocation === 'start' ? 'end' : 'start';
      const newLocations = { ...prev.locations };

      // Auto-unload passenger at destination
      if (prev.passenger) {
        newLocations[prev.passenger] = newBoatLocation;
      }
      
      const itemsOnNewBank = (Object.keys(newLocations) as Item[]).filter(item => newLocations[item] === newBoatLocation);

      return {
        ...prev,
        boatLocation: newBoatLocation,
        locations: newLocations,
        passenger: null, // Passenger is now on the bank
        moves: prev.moves + 1,
        message: `Rowing to the ${newBoatLocation} bank...`,
        selectedItemOnBank: itemsOnNewBank.length > 0 ? itemsOnNewBank.sort()[0] : null,
      };
    });
  }, [state.status]);
  
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (state.status !== 'playing') return;

    const { boatLocation, locations, passenger, selectedItemOnBank } = state;

    const itemsOnCurrentBank = (Object.keys(locations) as Item[]).filter(
      (item) => locations[item] === boatLocation && item !== passenger
    ).sort();

    switch(e.key) {
      case 'ArrowUp':
      case 'ArrowDown':
        e.preventDefault();
        if (itemsOnCurrentBank.length > 0) {
          const currentIndex = selectedItemOnBank ? itemsOnCurrentBank.indexOf(selectedItemOnBank) : -1;
          const offset = e.key === 'ArrowDown' ? 1 : -1;
          const nextIndex = (currentIndex + offset + itemsOnCurrentBank.length) % itemsOnCurrentBank.length;
          setState(prev => ({...prev, selectedItemOnBank: itemsOnCurrentBank[nextIndex]}));
        }
        break;
      
      case ' ':
      case 'Enter':
        e.preventDefault();
        if (selectedItemOnBank) {
          handleItemClick(selectedItemOnBank);
        }
        break;

      case 'ArrowLeft':
      case 'ArrowRight':
        e.preventDefault();
        handleRow();
        break;
    }

  }, [state, handleItemClick, handleRow]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    }
  }, [handleKeyDown]);

  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, item: Item) => {
    if (state.status !== 'playing') {
      e.preventDefault();
      return;
    }
    e.dataTransfer.setData('text/plain', item);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const handleDropOnBoat = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (state.status !== 'playing') return;

    const item = e.dataTransfer.getData('text/plain') as Item;
    
    if (state.locations[item] === state.boatLocation && state.passenger !== item) {
      setState(prev => ({
        ...prev,
        passenger: item,
        selectedItemOnBank: null,
      }));
    }
  };

  const handleReset = () => {
    setState(getInitialState());
  };

  const renderItem = (item: Item) => {
    const isDraggable = state.locations[item] === state.boatLocation && state.status === 'playing';
    return (
        <div
          key={item}
          onClick={() => handleItemClick(item)}
          className={`relative flex flex-col items-center justify-center p-2 sm:p-4 rounded-lg transition-all duration-200 w-20 h-20 sm:w-24 sm:h-24
            ${state.locations[item] === state.boatLocation && state.status === 'playing' ? 'cursor-pointer hover:bg-sky-700' : 'cursor-not-allowed opacity-50'}
            ${state.passenger === item ? 'bg-sky-600' : 'bg-slate-700/50'}
            ${state.selectedItemOnBank === item ? 'ring-4 ring-sky-400' : ''}`}
          aria-label={`Select ${item}`}
          tabIndex={0}
          draggable={isDraggable}
          onDragStart={(e) => handleDragStart(e, item)}
        >
          <span className="text-3xl sm:text-4xl">{EMOJIS[item]}</span>
          <span className="text-xs sm:text-sm capitalize mt-1">{item}</span>
        </div>
    )
  };

  const renderBank = (location: Location) => {
    const itemsOnBank = (Object.keys(state.locations) as Item[]).filter(
        item => state.locations[item] === location && state.passenger !== item
    ).sort();
    
    return (
      <div 
        className="bg-green-800/20 border-2 border-green-700/50 p-4 rounded-xl w-1/3 min-h-[200px] flex flex-col items-center justify-center"
      >
        <h2 className="text-xl font-bold text-green-300 mb-4 capitalize">{location} Bank</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {itemsOnBank.length > 0 ? itemsOnBank.map(renderItem) : <div className="h-24 opacity-0"></div>}
        </div>
      </div>
    );
  };
  
  const statusColor = state.status === 'won' ? 'text-green-400' : state.status === 'lost' ? 'text-red-400' : 'text-sky-300';

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-6xl mx-auto">
        <header className="text-center mb-6">
          <h1 className="text-4xl md:text-5xl font-bold text-sky-300">The River Crossing Puzzle</h1>
          <p className="text-slate-400 mt-2 text-lg">Get everything safely to the other side!</p>
        </header>

        <main className="space-y-6">
            <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700 text-center">
                <h2 className="text-xl font-semibold text-rose-400 mb-2">Rules & Controls</h2>
                <ul className="text-slate-300 space-y-1 max-w-3xl mx-auto">
                    <li>The boat can only carry one item at a time.</li>
                    <li>The Goat cannot be left alone with the Cabbage.</li>
                    <li>The Wolf cannot be left alone with the Cabbage.</li>
                    <li className="pt-2 font-semibold text-slate-200">
                        Click or Drag items to the boat to load them. Rowing automatically unloads the passenger.
                    </li>
                    <li className="font-semibold text-slate-200">
                        Keyboard: 
                        <kbd className="inline-block bg-slate-900 rounded px-2 py-1 text-sm mx-1">↑</kbd>
                        <kbd className="inline-block bg-slate-900 rounded px-2 py-1 text-sm mx-1">↓</kbd> to select, 
                        <kbd className="inline-block bg-slate-900 rounded px-2 py-1 text-sm mx-1">Space/Enter</kbd> to load, 
                        and <kbd className="inline-block bg-slate-900 rounded px-2 py-1 text-sm mx-1">←</kbd>
                        <kbd className="inline-block bg-slate-900 rounded px-2 py-1 text-sm mx-1">→</kbd> to row.
                    </li>
                </ul>
            </div>
          
            <div className="text-center p-3 rounded-lg bg-slate-800 border border-slate-700">
                <p className={`text-lg font-semibold transition-colors duration-300 ${statusColor}`}>{state.message}</p>
                 <p className="text-slate-400">Moves: {state.moves}</p>
            </div>

            {/* Game Area */}
            <div className="flex justify-between items-center w-full my-4">
                {renderBank('start')}
                
                <div 
                  className="w-1/3 min-h-[200px] mx-4 bg-sky-800/50 border-2 border-sky-700/50 rounded-lg relative overflow-hidden"
                >
                  <div
                    className={`absolute top-1/2 -translate-y-1/2 flex items-center justify-center transition-all ease-in-out duration-1000
                      ${state.boatLocation === 'start' ? 'left-0' : 'right-0'}`}
                    onDragOver={handleDragOver}
                    onDrop={handleDropOnBoat}
                    >
                      <div className={`flex items-center justify-center space-x-2 text-4xl ${state.boatLocation === 'end' ? 'flex-row-reverse space-x-reverse' : ''}`}>
                         <span title="Boat">{BOAT}</span>
                         <div className="w-24 h-24 flex items-center justify-center text-3xl transition-all duration-200 rounded-lg"
                         >
                             {state.passenger ? EMOJIS[state.passenger] : ''}
                         </div>
                      </div>
                  </div>
                </div>

                {renderBank('end')}
            </div>

            {/* Controls */}
            <div className="flex justify-center items-center space-x-4">
                <button 
                    onClick={handleRow} 
                    disabled={state.status !== 'playing'} 
                    className="px-8 py-3 bg-sky-600 text-white font-bold rounded-lg hover:bg-sky-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
                >
                    Row Boat
                </button>
                <button 
                    onClick={handleReset} 
                    className="px-8 py-3 bg-rose-600 text-white font-bold rounded-lg hover:bg-rose-500 transition-colors"
                >
                    Reset
                </button>
            </div>

        </main>
      </div>
    </div>
  );
};

export default App;
