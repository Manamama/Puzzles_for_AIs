import React, { useState, useCallback } from 'react';
import { CellState } from './types';
import Controls from './components/Controls';
import Grid from './components/Grid';

const App: React.FC = () => {
  const [matrixSize, setMatrixSize] = useState<number>(15);
  const [grid, setGrid] = useState<CellState[][]>(() =>
    Array.from({ length: 15 }, () => Array(15).fill(CellState.EMPTY))
  );
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [stageHistory, setStageHistory] = useState<CellState[][][]>([]);

  const handleGenerate = useCallback(() => {
    setIsGenerating(true);
    setStageHistory([]);

    const n = matrixSize;
    if (n <= 0) {
      setIsGenerating(false);
      return;
    }

    const newStages: CellState[][][] = [];
    let currentGrid = Array.from({ length: n }, () => Array(n).fill(CellState.EMPTY));
    
    let x = Math.floor(n / 2);
    let y = Math.floor(n / 2);
    currentGrid[y][x] = CellState.RED;

    let count = 1;
    const limit = Math.floor(n * n / 2) + 1;
    let step = 0;
    let direction = -1;

    // First stage, as per python script's initial print_grid()
    newStages.push(currentGrid.map(row => [...row]));

    let loopGuard = 0; // Failsafe against infinite loops
    while (count < limit && loopGuard < n * n) {
      loopGuard++;

      // This loop body exactly mimics the python script's `while` loop
      let shouldBreakOuter = false;
      for (let i = 0; i < step; i++) {
        let nx = x, ny = y;
        if (direction === 0) nx += 1;      // Right
        else if (direction === 1) ny += 1; // Down
        else if (direction === 2) nx -= 1; // Left
        else if (direction === 3) ny -= 1; // Up

        if (nx >= 0 && nx < n && ny >= 0 && ny < n) {
            x = nx;
            y = ny;
            currentGrid[y][x] = CellState.RED;
            count++;
        } else {
            // Out of bounds, stop this generation.
            shouldBreakOuter = true;
            break;
        }
      }
      
      // Store the state after the segment is drawn
      newStages.push(currentGrid.map(row => [...row]));
      
      if (shouldBreakOuter) {
        break;
      }

      // Update for next segment
      step += 1;
      direction = (direction + 1) % 4;
    }
    
    setStageHistory(newStages);
    setIsGenerating(false);
  }, [matrixSize]);

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 lg:p-8 font-sans">
      <div className="w-full max-w-7xl mx-auto flex flex-col lg:flex-row gap-8">
        <div className="lg:w-1/3 flex-shrink-0">
          <div className="bg-slate-800 p-6 rounded-2xl shadow-2xl sticky top-8">
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-white">Expanding Spiral Generator</h1>
              <p className="text-slate-400 mt-2">
                This application generates a special type of sparse spiral, showing every stage of its construction based on the provided algorithm.
              </p>
              <p className="text-slate-400 mt-4 font-medium">The Algorithm:</p>
                <ul className="list-disc list-inside text-slate-400 mt-1 space-y-1 text-sm">
                  <li>Begin at the center of the grid.</li>
                  <li>In a loop, draw a segment, then store the grid's state.</li>
                  <li>The segment length increases by one at every turn (0, 1, 2, 3...).</li>
                </ul>
            </div>
            <Controls
              matrixSize={matrixSize}
              setMatrixSize={(size: number) => {
                setMatrixSize(size);
                setGrid(Array.from({ length: size }, () => Array(size).fill(CellState.EMPTY)));
                setStageHistory([]);
              }}
              onGenerate={handleGenerate}
              isGenerating={isGenerating}
            />
          </div>
        </div>
        <div className="flex-grow">
            <div className="w-full h-[85vh] bg-slate-800 rounded-2xl shadow-inner p-4 lg:p-6 overflow-y-auto">
              {isGenerating ? (
                 <div className="flex items-center justify-center h-full text-slate-400">
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Generating stages...
                </div>
              ) : stageHistory.length > 0 ? (
                <>
                  <h2 className="text-xl font-semibold text-white mb-4 sticky top-0 bg-slate-800 py-2 z-10">Generation Stages</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {stageHistory.map((stageGrid, index) => (
                      <div key={index}>
                        <p className="text-slate-400 text-sm mb-1 font-medium">Stage {index + 1}</p>
                        <Grid grid={stageGrid} />
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                 <div className="w-full h-full flex items-center justify-center p-4">
                     <div className="w-full max-w-md aspect-square">
                        <Grid grid={grid} />
                     </div>
                 </div>
              )}
            </div>
        </div>
      </div>
       <footer className="text-center text-slate-500 mt-8 py-4">
        <p>Built with React, TypeScript, and Tailwind CSS.</p>
      </footer>
    </div>
  );
};

export default App;
