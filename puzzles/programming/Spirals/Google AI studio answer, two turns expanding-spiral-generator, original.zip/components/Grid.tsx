
import React from 'react';
import { CellState } from '../types';
import Cell from './Cell';

interface GridProps {
  grid: CellState[][];
}

const Grid: React.FC<GridProps> = ({ grid }) => {
  const gridSize = grid.length;

  return (
    <div
      className="grid w-full h-full gap-1 p-2 bg-slate-800 rounded-xl shadow-inner"
      style={{ gridTemplateColumns: `repeat(${gridSize}, minmax(0, 1fr))` }}
    >
      {grid.map((row, y) =>
        row.map((cellState, x) => (
          <Cell key={`${y}-${x}`} state={cellState} />
        ))
      )}
    </div>
  );
};

export default Grid;
