
import React from 'react';
import { CellState } from '../types';

interface CellProps {
  state: CellState;
}

const Cell: React.FC<CellProps> = React.memo(({ state }) => {
  const baseClasses = 'w-full aspect-square rounded-[2px] transition-colors duration-300';
  
  const colorClass = state === CellState.RED
    ? 'bg-rose-500'
    : 'bg-slate-700';

  return <div className={`${baseClasses} ${colorClass}`}></div>;
});

export default Cell;
