import React, { useState, useCallback } from 'react';
import { CellState } from './types';
import Controls from './components/Controls';
import Grid from './components/Grid';

const EMOJI_MAP = {
  [CellState.RED]: '🟥',
  [CellState.EMPTY]: '⬜',
};

const App: React.FC = () => {
  const [matrixSize, setMatrixSize] = useState<number>(15);
  const [speed, setSpeed] = useState<number>(50);
  const [grid, setGrid] = useState<CellState[][]>(() => 
    Array.from({ length: 15 }, () => Array(15).fill(CellState.EMPTY))
  );
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [finalString, setFinalString] = useState<string | null>(null);

  const generateFinalString = (finalGrid: CellState[][]): void => {
    const output = finalGrid
      .map(row => row.map(cell => EMOJI_MAP[cell]).join(''))
      .join('\n');
    setFinalString(output);
  };

  const handleGenerate = useCallback(async () => {
    setIsGenerating(true);
    setFinalString(null);

    const n = matrixSize;
    if (n <= 0) {
      setIsGenerating(false);
      return;
    }
    
    const newGrid = Array.from({ length: n }, () => Array(n).fill(CellState.EMPTY));
    setGrid(newGrid);
    
    // Allow the UI to update to the empty grid before starting
    await new Promise(resolve => setTimeout(resolve, 50));

    let x = Math.floor(n / 2);
    let y = Math.floor(n / 2);
    
    // Directions: 0: Right, 1: Up, 2: Left, 3: Down
    const directions = [[1, 0], [0, -1], [-1, 0], [0, 1]];
    let directionIndex = 0;
    
    let stepsInSegment = 1;
    let turnAfterSteps = 1;
    let stepsTaken = 0;

    // The loop will run until we go out of bounds. n * n is a safe upper limit.
    for (let i = 0; i < n * n; i++) {
      if (x >= 0 && x < n && y >= 0 && y < n) {
        newGrid[y][x] = CellState.RED;
        // Create a deep copy for state update to trigger re-render
        setGrid(prevGrid => {
            const updatedGrid = prevGrid.map(row => [...row]);
            updatedGrid[y][x] = CellState.RED;
            return updatedGrid;
        });
        await new Promise(resolve => setTimeout(resolve, speed));
      } else {
        // Spiral has gone out of the grid boundaries, stop generating.
        break; 
      }

      const [dx, dy] = directions[directionIndex];
      x += dx;
      y += dy;
      stepsTaken++;

      if (stepsTaken === turnAfterSteps) {
        stepsTaken = 0;
        directionIndex = (directionIndex + 1) % 4;
        // Increase the arm length at every turn (1, 2, 3, 4...)
        stepsInSegment++; 
        turnAfterSteps = stepsInSegment;
      }
    }
    
    generateFinalString(newGrid);
    setIsGenerating(false);
  }, [matrixSize, speed]);

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 lg:p-8 font-sans">
      <div className="w-full max-w-7xl mx-auto flex flex-col lg:flex-row gap-8">
        <div className="lg:w-1/3 flex-shrink-0">
          <div className="bg-slate-800 p-6 rounded-2xl shadow-2xl">
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-white">Expanding Spiral Generator</h1>
              <p className="text-slate-400 mt-2">
                This application generates a special type of sparse spiral. Unlike a standard, tight spiral, this one expands rapidly, leaving open space between its arms.
              </p>
              <p className="text-slate-400 mt-4 font-medium">The Algorithm:</p>
                <ul className="list-disc list-inside text-slate-400 mt-1 space-y-1 text-sm">
                  <li>Begin at the center of the grid.</li>
                  <li>Move in a spiral path (Right, Up, Left, Down...).</li>
                  <li><strong>The key:</strong> The length of each segment increases by one at every turn. (Move 1 step, turn, move 2 steps, turn, move 3 steps...).</li>
                </ul>
              <p className="text-slate-400 mt-4">
                Adjust the grid size and speed, then generate to see this unique pattern come to life.
              </p>
            </div>
            <Controls
              matrixSize={matrixSize}
              setMatrixSize={(size: number) => {
                setMatrixSize(size);
                setGrid(Array.from({ length: size }, () => Array(size).fill(CellState.EMPTY)));
              }}
              speed={speed}
              setSpeed={setSpeed}
              onGenerate={handleGenerate}
              isGenerating={isGenerating}
            />
             {finalString && (
              <div className="mt-6">
                <h2 className="text-xl font-semibold text-white mb-2">Final Result</h2>
                <pre className="bg-slate-900 text-xs p-3 rounded-lg overflow-x-auto select-all">
                  <code>{finalString}</code>
                </pre>
              </div>
            )}
          </div>
        </div>
        <div className="flex-grow flex items-center justify-center">
            <div className="w-full max-w-2xl aspect-square">
                 <Grid grid={grid} />
            </div>
        </div>
      </div>
       <footer className="text-center text-slate-500 mt-8">
        <p>Built with React, TypeScript, and Tailwind CSS.</p>
      </footer>
    </div>
  );
};

export default App;