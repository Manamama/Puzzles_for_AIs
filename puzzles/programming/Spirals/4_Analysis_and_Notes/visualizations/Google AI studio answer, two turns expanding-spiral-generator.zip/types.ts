
export enum CellState {
  EMPTY = 0,
  RED = 1,
}
