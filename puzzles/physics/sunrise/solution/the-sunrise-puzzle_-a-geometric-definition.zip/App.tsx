
import React, { useState, useEffect, useRef } from 'react';

// Main App component
const App: React.FC = () => {
    // State for Earth's rotation angle
    const [rotation, setRotation] = useState(0);
    // Ref for the animation frame
    const requestRef = useRef<number | null>(null);

    // Animation loop using requestAnimationFrame
    const animate = () => {
        // Slower rotation for better visualization
        setRotation(prevRotation => (prevRotation - 0.1) % 360);
        requestRef.current = requestAnimationFrame(animate);
    };

    // Start and stop the animation
    useEffect(() => {
        requestRef.current = requestAnimationFrame(animate);
        return () => {
            if(requestRef.current) {
                cancelAnimationFrame(requestRef.current);
            }
        };
    }, []);

    return (
        // Main container
        <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 text-slate-100 overflow-hidden">
            <div className="w-full max-w-5xl mx-auto">
                <header className="text-center mb-10">
                    <h1 className="text-4xl md:text-5xl font-bold text-amber-300 tracking-tight">The Sunrise Puzzle</h1>
                    <p className="text-slate-400 mt-2 text-lg">Defining Sunrise Through Geometry, Not Metaphor</p>
                </header>

                <main className="grid md:grid-cols-5 gap-8 items-center">
                    {/* Visualizer Column (takes 2/5 width) */}
                    <div className="md:col-span-2 flex items-center justify-center p-4">
                        <svg viewBox="0 0 400 400" className="w-full max-w-sm">
                            <defs>
                                <radialGradient id="sunGlow">
                                    <stop offset="20%" stopColor="rgba(252, 211, 77, 1)" />
                                    <stop offset="100%" stopColor="rgba(251, 191, 36, 0)" />
                                </radialGradient>
                            </defs>
                            {/* Sun and its glow */}
                            <circle cx="0" cy="200" r="100" fill="url(#sunGlow)" />
                            <circle cx="0" cy="200" r="30" fill="white" />
                            
                            {/* Earth Group for rotation */}
                            <g transform={`rotate(${rotation} 250 200)`}>
                                {/* Earth Body */}
                                <circle cx="250" cy="200" r="60" fill="#3b82f6" />
                                {/* Observer approaching sunrise */}
                                <circle cx="250" cy="140" r="4" fill="#ef4444" stroke="white" strokeWidth="1" />
                            </g>
                            {/* Earth's Shadow (Night) - NOW STATIC */}
                            <path d="M 250 140 A 60 60 0 1 0 250 260 Z" fill="rgba(0,0,0,0.5)" />
                        </svg>
                    </div>

                    {/* Explanation Column (takes 3/5 width) */}
                    <div className="md:col-span-3 space-y-6">
                        <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700">
                            <h2 className="text-2xl font-semibold text-rose-400 mb-3">1. The Correct Definition</h2>
                            <p className="text-slate-300 leading-relaxed">
                                "Darkness" is not a physical substance; it is the planet's own shadow cast into space. "Sunrise" is the precise geometric event where an observer's location on the planet's surface rotates out of this shadow and into the pre-existing field of sunlight.
                            </p>
                        </div>
                        
                        <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700">
                             <h2 className="text-2xl font-semibold text-amber-400 mb-3">2. The Puzzle's Axiom</h2>
                             <p className="text-slate-300 leading-relaxed">The statement "Sunrise occurs at 6:00 a.m." is a **fixed axiom** of the puzzle. It defines the scheduled time of the *observed event*. It is not a calculation result to be changed, but a rule that the universe of the puzzle must follow.</p>
                        </div>

                        <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700">
                           <h2 className="text-2xl font-semibold text-teal-300 mb-3">3. The Logical Conclusion</h2>
                           <p className="text-slate-300 leading-relaxed">
                           The speed of light only affects the delay in *perceiving* a celestial event. It does not alter the mechanical speed of Earth's rotation or the geometry of its shadow. Since the puzzle fixes the observation time, the underlying physics must conform.
                           </p>
                           <p className="font-bold text-white mt-4 text-lg">
                           Therefore, changing the speed of light has **no effect** on the scheduled 6:00 a.m. sunrise time.
                           </p>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
};

export default App;
